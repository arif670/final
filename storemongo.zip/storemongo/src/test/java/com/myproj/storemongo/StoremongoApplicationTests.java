package com.myproj.storemongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoremongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
