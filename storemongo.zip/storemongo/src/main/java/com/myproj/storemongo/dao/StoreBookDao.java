package com.myproj.storemongo.dao;

import java.awt.List;
import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.mongodb.client.result.DeleteResult;
import com.myproj.storemongo.model.StoreBook;


@Component
public class StoreBookDao {
	@Autowired
	MongoTemplate mongoTemplate;


	public StoreBook saveBook(StoreBook storebook)
	{
	try
	{
	mongoTemplate.save(storebook);
	return storebook;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	public ArrayList<StoreBook> getAllbooks()
	{

	return (ArrayList<StoreBook>) mongoTemplate.findAll(StoreBook.class);

	}
	
	public StoreBook createBook(StoreBook storebook)
	{
	try
	{
	mongoTemplate.save(storebook);
	return storebook;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	public StoreBook UpdateBook(StoreBook storebook)
	{
	try
	{
	mongoTemplate.save(storebook);
	return storebook;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	
	public Object DelBook(String name)
	{
		Query query=new Query(Criteria.where("name").is(name));
		DeleteResult storebook= mongoTemplate.remove(query,StoreBook.class);
	    if(storebook!=null)
		{
			return storebook;
		}
		return "no data Found";
	}

	

	}
	
	


